<?php return [
    'logo'                  => '/images/logo-small.png',
    'name'                  => 'Name',
    'email'                 => 'Email',
    'password'              => 'Password',
    'password_confirmation' => 'Confirm password',
    'submit'                => 'Submit',
    'signin'                => 'Sign In',
    'forgotten'             => 'Forgotten Password',
];
