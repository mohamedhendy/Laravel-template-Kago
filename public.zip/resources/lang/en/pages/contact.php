<?php return [
    'contact-title'        => 'Contact us',
    'contact-name'         => 'Name',
    'contact-email'        => 'Email',
    'contact-message'      => 'Message content',
    'send-button'          => 'Send',
    'user-icon'            => 'fas fa-user',
    'mail-icon'            => 'fas fa-envelope',
    'contact-address'      => 'Address',
    'contact-phone-number' => 'Phone number',
    'map-icon'             => '<i class="fas fa-map-marker-alt"></i>',
    'contact-phone-icon'   => '<i class="fas fa-phone-alt"></i>',
    'email-icon'           => '<i class="fas fa-envelope"></i>',
    'location-place'=> 'http://maps.google.com/?q=1200 Pennsylvania Ave SE, Washington, District of Columbia, 20003'

];
