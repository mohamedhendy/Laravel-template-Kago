<?php return [
    'title'        => 'backoffice',
    'switch-to-en' => 'En',
    'switch-to-ar' => 'Ar',
    'signout-icon' => '<i class="fas fa-sign-out-alt"></i>',
];
