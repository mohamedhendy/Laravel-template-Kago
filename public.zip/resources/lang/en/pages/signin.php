<?php return [
    'logo'      => '/images/logo-small.png',
    'email'     => 'Email',
    'password'  => 'Password',
    'remember'  => 'Remember Me',
    'submit'    => 'Submit',
    'signup'    => 'Sign Up',
    'forgotten' => 'Forgotten Password',
];
