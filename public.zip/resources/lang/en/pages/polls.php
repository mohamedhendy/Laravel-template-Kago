<?php return [
    'system-title' => 'Questionnaire system',
    'visit-count'  => 'How often do you visit the school site?',
    'visit-daily'  => 'Daily',
    'visit-weekly' =>'Weekly',
    'visit-never'  =>'Never'
];
