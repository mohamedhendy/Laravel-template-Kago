<?php return [
    'recruitment-title'             => 'Recruitment',
    'arabic-teacher'                => 'Arabic teacher',
    'mathematics-teacher'           => 'Mathematics Teacher',
    'chemistry-teacher'             => 'Chemistry teacher',
    'excerpt-paragraph-arabic'      => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt',
    'excerpt-paragraph-mathematics' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt',
    'excerpt-paragraph-chemistry'   => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt',
    'arabic-teacher-image'          => 'http://capitalschools.edu.eg/wp-content/uploads/2017/07/school-300x300.jpg',
    'mathematics-teacher-image'     => 'http://capitalschools.edu.eg/wp-content/uploads/2017/07/school-300x300.jpg',
    'chemistry-teacher-image'       => 'http://capitalschools.edu.eg/wp-content/uploads/2017/07/school-300x300.jpg',
    'apply-button'                  => 'Apply'
];
