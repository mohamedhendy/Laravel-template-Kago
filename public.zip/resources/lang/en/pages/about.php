<?php return [
    'about-title'       => 'About Schools',
    'vision-title'      => 'Vision',
    'message-title'     => 'The Message',
    'strategy-title'    => 'Strategy',
    'president-speech'  => 'The President\'s Speech',
    'school-first-img'  => 'https://analyticsindiamag.com/wp-content/uploads/2017/09/google-office-300x300.jpg',
    'school-second-img' => 'https://theretailconnection.net/wp-content/uploads/2019/01/TRC-Austin-office-300x300.jpg',
    'school-third-img'  => 'https://www.familyhandyman.com/wp-content/uploads/2019/09/Office-300x300.jpg',
    'school-forth-img'  => 'https://mjbird.co.uk/wp-content/uploads/2018/11/office-300x300.jpg',
    'school-fifth-img'  => 'http://www.grangerconstruction.com/wp-content/uploads/2018/04/Grand-Rapids-Office-300x300.jpg',
    'president-picture' =>'https://i0.wp.com/500wordsmag.com/wp-content/uploads/2019/06/Original-Blue-For-Sudan.jpeg',
    'President-excerpt'  => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidun tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidun Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidun tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidun'

];
