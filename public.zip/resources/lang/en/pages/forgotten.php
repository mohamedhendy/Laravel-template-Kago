<?php return [
    'logo'   => '/images/logo-small.png',
    'title'  => 'Forgotten Password',
    'email'  => 'Email',
    'submit' => 'Submit',
    'signin' => 'Sign In',
    'signup' => 'Sign Up',
];
