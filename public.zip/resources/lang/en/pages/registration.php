<?php return [
        'application-title'    => 'Admission and Registration',
        'registration-title'   =>'Registration Requirements In Schools',
        'registration-excerpt' =>'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt'

];
