<?php return [
    'apply-title'          => 'Apply',
    'apply-full-name'      => 'Full-name',
    'apply-phone-number'   => 'Phone number',
    'apply-email'          => 'Apply email',
    'apply-cv'             => 'Curriculum Vitae',
    'apply-experiences'    => 'Experiences',
    'apply-button'         => 'Apply',
    'user-icon'            => 'fas fa-user',
    'phone-icon'           => 'fas fa-phone-alt',
    'mail-icon'            => 'fas fa-envelope',
    'file-icon'            => 'fas fa-paperclip file-icon'

];
