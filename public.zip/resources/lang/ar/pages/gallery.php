<?php return [
    'images-title' => 'البوم الصور',
    'large-image'  => 'https://earthbornpaints.co.uk/wp-content/uploads/2019/01/Earthborn-2019-paint-colours-featured-image-800x300.jpg',
    'small-image'  => 'https://www.harvestlink.com/images/kkcontent_thumbs/thumb_110_124_1551953591_pure-color-orange.jpg',
    'medium-image' => 'https://www.tiledepotny.com/wp-content/uploads/2018/02/12x48-4-520x200.jpg'
];
