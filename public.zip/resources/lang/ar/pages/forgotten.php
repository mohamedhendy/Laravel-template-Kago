<?php return [
    'logo'   => '/images/logo-small.png',
    'title'  => 'كلمة سر منسية',
    'email'  => 'البريد الإلكترونى',
    'submit' => 'ارسال',
    'signin' => 'تسجيل الدخول',
    'signup' => 'التسجيل',
];
