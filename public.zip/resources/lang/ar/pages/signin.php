<?php return [
    'logo'      => '/images/logo-small.png',
    'email'     => 'تسجيل الدخول',
    'password'  => 'الرقم السري',
    'remember'  => 'تذكرنى فى المره المقبلة',
    'submit'    => 'ارسال',
    'signup'    => 'التسجيل',
    'forgotten' => 'كلمة سر منسية',
];
