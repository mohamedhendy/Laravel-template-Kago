<?php return [
    'apply-title'          => 'التقدم للوظيفة',
    'apply-full-name'      => 'الإسم كاملاً',
    'apply-phone-number'   => 'الجوال',
    'apply-email'          => 'الإيميل',
    'apply-cv'             => 'السيرة الذاتيه',
    'apply-experiences'    => 'الخبرات',
    'apply-button'         => 'التقدم',
    'user-icon'            => 'fas fa-user',
    'phone-icon'           => 'fas fa-phone-alt',
    'mail-icon'            => 'fas fa-envelope',
    'file-icon'            => 'fas fa-paperclip file-icon'

];
