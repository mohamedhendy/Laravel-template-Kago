<?php return [
    'logo'                  => '/images/logo-small.png',
    'name'                  => 'الإسم',
    'email'                 => 'الإيميل',
    'password'              => 'الرقم السري',
    'password_confirmation' => 'تأكيد الرقم السري',
    'submit'                => 'ارسال',
    'signin'                => 'تسجيل الدخول',
    'forgotten'             => 'كلمة سر منسيه ',
];
