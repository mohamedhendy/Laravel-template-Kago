<?php return [
    'system-title' => 'نظام االستبانة',
    'visit-count'  => 'ما هو معدل زيارتك لموقع المدرسة ؟',
    'visit-daily'  => 'يومياً',
    'visit-weekly' =>'أسبوعياً',
    'visit-never'  =>'لا أزوره أبداً'
];
