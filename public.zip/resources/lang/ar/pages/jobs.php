<?php return [
    'recruitment-title'             => 'التوظيف',
    'arabic-teacher'                => 'مدرس لغه عربية',
    'mathematics-teacher'           => 'مدرس رياضيات',
    'chemistry-teacher'             => 'مدرس كيمياء',
    'excerpt-paragraph-arabic'      => 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى',
    'excerpt-paragraph-mathematics' => 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى',
    'excerpt-paragraph-chemistry'   => 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى',
    'arabic-teacher-image'          => 'http://capitalschools.edu.eg/wp-content/uploads/2017/07/school-300x300.jpg',
    'mathematics-teacher-image'     => 'http://capitalschools.edu.eg/wp-content/uploads/2017/07/school-300x300.jpg',
    'chemistry-teacher-image'       => 'http://capitalschools.edu.eg/wp-content/uploads/2017/07/school-300x300.jpg',
    'apply-button'                  => 'التقدم'
];
