<?php return [
    'contact-title'        => 'إتصل بنا ',
    'contact-name'         => 'الإسم',
    'contact-email'        => 'البريد الإلكتروني',
    'contact-message'      => 'محتوى الرساله',
    'send-button'          => 'ارسال',
    'contact-address'      => 'العنوان',
    'contact-phone-number' => 'رقم الموبيل',
    'user-icon'            => 'fas fa-user',
    'mail-icon'            => 'fas fa-envelope',
    'map-icon'             => '<i class="fas fa-map-marker-alt"></i>',
    'contact-phone-icon'   => '<i class="fas fa-phone-alt"></i>',
    'email-icon'           => '<i class="fas fa-envelope"></i>',
    'location-place'=> 'http://maps.google.com/?q=1200 Pennsylvania Ave SE, Washington, District of Columbia, 20003'

];
