<?php return [
    'about-title'       => 'عن المدارس',
    'vision-title'      => 'الرؤية',
    'message-title'     => 'الرساله',
    'strategy-title'    => 'الإستراتيجية',
    'president-speech'  => 'كلمة الرئيس',
    'school-first-img'  => 'https://analyticsindiamag.com/wp-content/uploads/2017/09/google-office-300x300.jpg',
    'school-second-img' => 'https://theretailconnection.net/wp-content/uploads/2019/01/TRC-Austin-office-300x300.jpg',
    'school-third-img'  => 'https://www.familyhandyman.com/wp-content/uploads/2019/09/Office-300x300.jpg',
    'school-forth-img'  => 'https://mjbird.co.uk/wp-content/uploads/2018/11/office-300x300.jpg',
    'school-fifth-img'  => 'http://www.grangerconstruction.com/wp-content/uploads/2018/04/Grand-Rapids-Office-300x300.jpg',
    'president-picture' =>'https://i0.wp.com/500wordsmag.com/wp-content/uploads/2019/06/Original-Blue-For-Sudan.jpeg',
    'President-excerpt'  => 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.
    إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.
    ومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.'

];
