

<script defer src="{{ asset(mix('/js/manifest.js')) }}"></script>
<script defer src="{{ asset(mix('/js/vendor.js')) }}"></script>
<script defer src="{{ asset(mix('/js/front.js')) }}"></script>
