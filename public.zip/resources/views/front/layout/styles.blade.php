<link rel="stylesheet" href="{{ mix('css/base.css') }}">
<link rel="stylesheet" href="{{ mix('css/front.css') }}">