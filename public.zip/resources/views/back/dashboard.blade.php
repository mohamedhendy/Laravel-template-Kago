@extends('back.layout')
@php
$page = page('dashboard');
$title = $page('title');
@endphp
@section('content')

@endsection
