<div class="container">
  <div class="row">
    <div class="col-md-3 col-sm-6">
      <ul class="list-unstyled">
        <li class="mb-3">
           <a href="<?php echo e($site('address','location')); ?>"
            target="_blank" rel="noopener noreferrer">
            <?php echo $site('map-icon'); ?>

            <?php echo e($site('address', 'contact')); ?>

          </a>
        </li>
        <li class="mb-3">
          <a href="tel:<?php echo e($site('phone')); ?>" target="_blank" rel="noopener noreferrer"> <?php echo $site('phone-icon', 'contact'); ?>

            <?php echo e($site('phone-number', 'contact')); ?>

          </a>
        </li>
        <li class="mb-3">
          <a href="mailto:<?php echo e($site('email')); ?>" target="_blank" rel="noopener noreferrer"> <?php echo $site('email-icon'); ?> <?php echo e($site('email', 'contact')); ?>


          </a>
        </li>
      </ul>
    </div>
    <div class="col-md-3 col-sm-6">
      <ul class="list-unstyled">
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.home')); ?>">
            <?php echo e($site('home-name', 'menu')); ?></a>
        </li>
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.about')); ?>">
            <?php echo e($site('about-name','menu')); ?></a></li>
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.registration')); ?>">
            <?php echo e($site('registration-name','menu')); ?></a></li>
      </ul>
    </div>
    <div class="col-md-3 col-sm-6">
      <ul class="list-unstyled">
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.news')); ?>">
            <?php echo e($site('news-name','menu')); ?></a></li>
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.jobs')); ?>">
            <?php echo e($site('jobs-name', 'menu')); ?></a></li>
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.polls')); ?>">
            <?php echo e($site('polls-name', 'menu')); ?></a></li>
      </ul>
    </div>
    <div class="col-md-3 col-sm-6">
      <ul class="list-unstyled">
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.gallery')); ?>">
            <?php echo e($site('gallery-name', 'menu')); ?></a>
        </li>
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.jobs-application')); ?>">
            <?php echo e($site('jobs-application-name', 'menu')); ?></a></li>
        <li class="mb-3"> <a  rel="noopener noreferrer"
            href="<?php echo e(route('front.contact')); ?>">
            <?php echo e($site('contact-name', 'menu')); ?></a></li>
      </ul>
    </div>
  </div>
  <div class="text-center footer-log">
    <a class="reg-button" href="<?php echo e(route('auth.signup')); ?>"><?php echo e($site('register')); ?></a>
    <a class="login-button" href="<?php echo e(route('auth.signin')); ?>"> <?php echo e($site('login')); ?></a>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/front/layout/footer.blade.php ENDPATH**/ ?>