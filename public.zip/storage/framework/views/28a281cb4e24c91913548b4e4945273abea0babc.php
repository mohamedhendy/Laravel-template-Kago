<?php
$appTitle = $site('title');
$description = $site('description');
?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="content-language" content="<?php echo e($locale); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,user-scalable=no">
<meta name="referrer" content="origin-when-cross-origin">
<meta name="author" content="https://gulfdatas.com">
<meta name="robot" content="index, follow, noarchive, nosnippet, notranslate">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo e(trim(implode(' | ', [$appTitle, $title ?? '']), ' |')); ?></title>
<meta name="description" itemprop="description" content="<?php echo e($description); ?>">

<link rel="canonical" href="<?php echo e(canonicalUrl()); ?>">
<?php $__currentLoopData = urlsForOtherLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<link rel="alternate" href="<?php echo e($url); ?>" hreflang="<?php echo e($locale); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/auth/layout/meta.blade.php ENDPATH**/ ?>