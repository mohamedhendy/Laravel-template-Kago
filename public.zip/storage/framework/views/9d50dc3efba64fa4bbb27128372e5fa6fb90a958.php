<?php $__currentLoopData = [
  'google'    => 'fab fa-google',
  'vimeo'     => 'fab fa-vimeo-v',
  'linkedin'  => 'fab fa-linkedin-in',
  'rss'       => 'fas fa-rss',
  'twitter'   => 'fab fa-twitter',
  'facebook'  => 'fab fa-facebook-f',
  'snapchat'  => 'fab fa-snapchat',
  'instagram' => 'fab fa-instagram',
]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if(!empty($link = $site("$key-link", 'social'))): ?>
    <div class="d-inline-block">
      <a target="_blank" rel="nofollow noopener noreferrer" href="<?php echo e(url($link)); ?>">
        <i class="<?php echo e($class); ?>"></i>
      </a>
    </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/front/layout/social.blade.php ENDPATH**/ ?>