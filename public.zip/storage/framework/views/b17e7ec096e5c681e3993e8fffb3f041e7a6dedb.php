<section class="second-section text-center pt-5">
  <div class="container">
    <div class="welcom-section">
      <h1 class="pt-5 "><?php echo e($page('title','welcome')); ?></h1>
      <p class="mb-5 attribute text-center"><?php echo e($page('excerpt', 'welcome')); ?></p>
      <a href="<?php echo e(route('auth.signup')); ?>"
        class="mb-5"><?php echo e($page('button','register')); ?></a>
    </div>
  </div>
  <div class="about-section">
    <h3 class="text-capitalize"><?php echo e($page('about')); ?></h3>
    <div class="about-schools d-md-flex justify-content-center">
      <img class="first-img" src="<?php echo e($page('about-first-img')); ?>" alt="image">
      <img class="second-img" src="<?php echo e($page('about-second-img')); ?>" alt="image">
    </div>
  </div>
</section>
<?php /**PATH C:\xampp\htdocs\Laravel\kag-school\resources\views/front/home/home-welcome.blade.php ENDPATH**/ ?>