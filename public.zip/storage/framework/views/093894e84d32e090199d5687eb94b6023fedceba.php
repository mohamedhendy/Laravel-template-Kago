<?php
$page = page('polls');
$title = $page('title');
?>
<?php $__env->startSection('content'); ?>
<div class=" polls">
  <div class="container">
    <h1 class="text-center"><?php echo e($page('title','system')); ?></h1>
  </div>
  <div class="result">
    <div class="m-auto   w-50 question container ">
      <h3 class="text-center"><?php echo e($page('visit-count')); ?></h3>
      <ul class="list-unstyled px-0">
        <li>
          <div class="row">
            <div class="col-md-4 col-sm-12"><label
                for="daily"><?php echo e($page('daily','visit')); ?></label></div>
            <div class="col-2"><input type="radio" name="visit"  id="daily">
            </div>
            <div class="col-md-6 col-sm-10">
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 25%">
                </div>
              </div>
            </div>
          </div>
        </li>
        <li>
          <div class="row">
            <div class="col-md-4 col-sm-12"><label
                for="week"><?php echo e($page('weekly','visit')); ?></label></div>
            <div class="col-2"><input type="radio" name="visit" checked id="week">
            </div>
            <div class="col-md-6 col-sm-10">
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 35%">
                </div>
              </div>
            </div>
          </div>
        </li>
        <li>
          <div class="row">
            <div class="col-md-4 col-sm-12"><label
                for="never"><?php echo e($page('never','visit')); ?></label></div>
            <div class="col-2"><input type="radio" name="visit" id="never">
            </div>
            <div class="col-md-6 col-sm-10">
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 50%">
                </div>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/front/polls.blade.php ENDPATH**/ ?>