<?php
$page = page('home');
$title = $page('title');
?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.home.home-carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('front.home.home-welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="third-section">
  <h3 class="text-center text-capitalize"><?php echo e($page('exhibition')); ?></h3>
  <div class="slide-plugin">
    <div class="items-offers m-auto">
      <div class="autoplay" id="img-slider">
        <div class="img-slide">
          <img src="<?php echo e($page('exhibition-first-img')); ?>" alt="image" />
        </div>
        <div class="img-slide">
          <img src="<?php echo e($page('exhibition-second-img')); ?>" alt="image" />
        </div>
        <div class="img-slide">
          <img src="<?php echo e($page('exhibition-third-img')); ?>" alt="image" />
        </div>
        <div class="img-slide">
          <img src="<?php echo e($page('exhibition-forth-img')); ?>" alt="image" />
        </div>
        <div class="img-slide">
          <img src="<?php echo e($page('exhibition-fifth-img')); ?>" alt="image" />
        </div>
      </div>
    </div>
  </div>
</section>
<?php echo $__env->make('front.home.home-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('front.home.home-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\kag-school\resources\views/front/home.blade.php ENDPATH**/ ?>