<section class="forth-section">
    <h3 class="text-center text-capitalize pt-3"><?php echo e($page('activity')); ?></h3>
    <div class="imgs m-auto overflow-hidden w-50">
      <div class="activity d-flex justify-content-center">
        <div class="activity-img pt-5 pb-5">
          <img class="w-100" src="<?php echo e($page('first-activity-img')); ?>" alt="">
          <img class="w-100" src="<?php echo e($page('second-activity-img')); ?>" alt="">
        </div>
        <div class="activity-img">
          <img class="w-100" src="<?php echo e($page('third-activity-img')); ?>" alt="">
          <img class="w-100" src="<?php echo e($page('forth-activity-img')); ?>" alt="">
        </div>
        <div class="activity-img pt-5 pb-5">
          <img class="w-100" src="<?php echo e($page('fifth-activity-img')); ?>" alt="">
          <img class="w-100" src="<?php echo e($page('sixth-activity-img')); ?>" alt="">
        </div>
      </div>
    </div>
  </section>
  <section class="fifth-section">
    <h3 class="text-center text-capitalize"><?php echo e($page('exhibition')); ?></h3>
    <div>
      <img class="w-100" src="<?php echo e($page('goals')); ?>" alt="">
    </div>
  </section>
<?php /**PATH C:\xampp\htdocs\Laravel\kag-school\resources\views/front/home/home-activity.blade.php ENDPATH**/ ?>