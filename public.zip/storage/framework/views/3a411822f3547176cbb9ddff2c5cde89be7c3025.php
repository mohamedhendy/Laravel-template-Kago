<?php echo $site('copyright'); ?>

<?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/front/layout/copyright.blade.php ENDPATH**/ ?>