<?php
$page = page('jobs');
$title = $page('title');
?>
<?php $__env->startSection('content'); ?>
<div class="jobs-body">
  <div class="container">
    <h1 class="text-center py-5"><?php echo e($page('title', 'recruitment')); ?></h1>
  </div>
  <div class="">
    <div class=" teacher-content py-3 my-3">
      <div class="container py-2">
        <div class="row">
          <div class="offset-md-1 offset-lg-2 col-md-4">
            <img class="w-100 h-100" src="<?php echo e($page('image','arabic-teacher')); ?>" alt="">
          </div>
          <div class="col-md-6">
            <div class="flex-column ">
              <h3 class="text-capitalize"><?php echo e($page('teacher','arabic')); ?></h3>
              <p><?php echo e($page('paragraph-arabic','excerpt')); ?></p>
              <a href="<?php echo e(route('front.jobs-application')); ?>"><?php echo e($page('button','apply')); ?></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class=" teacher-content py-2 my-3">
      <div class="container py-2">
        <div class="row">
          <div class="offset-md-1 offset-lg-2 col-md-4">
            <img class="w-100 h-100" src="<?php echo e($page('image','mathematics-teacher')); ?>"
              alt="">
          </div>
          <div class="col-md-6">
            <div class="flex-column ">
              <h3 class="text-capitalize"><?php echo e($page('teacher','mathematics')); ?></h3>
              <p><?php echo e($page('paragraph-mathematics','excerpt')); ?></p>
            <a href="<?php echo e(route('front.jobs-application')); ?>"><?php echo e($page('button','apply')); ?></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class=" teacher-content py-2 my-3">
      <div class="container py-2">
        <div class="row">
          <div class="offset-md-1 offset-lg-2 col-md-4">
            <img class="w-100 h-100" src="<?php echo e($page('image','chemistry-teacher')); ?>"
              alt="">
          </div>
          <div class="col-md-6">
            <div class="flex-column ">
              <h3 class="text-capitalize"><?php echo e($page('teacher','chemistry')); ?></h3>
              <p><?php echo e($page('paragraph-chemistry','excerpt')); ?></p>
              <a href="<?php echo e(route('front.jobs-application')); ?>"><?php echo e($page('button','apply')); ?></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/front/jobs.blade.php ENDPATH**/ ?>