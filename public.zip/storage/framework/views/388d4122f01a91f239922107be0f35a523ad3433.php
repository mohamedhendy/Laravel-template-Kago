<?php
$page = page('signup');
$title = $page('title');
?>
<?php $__env->startSection('content'); ?>
<div class="page-sign">
  <div class="container-sign">
    <div class="card">
      <div class="card-header">
        <img src="<?php echo e(url(asset($page('logo')))); ?>">
      </div>
      <div class="card-body">
        <form method="POST"><?php echo csrf_field(); ?>
          <div class="form-group">
            <label><?php echo e($page('name')); ?></label>
            <input type="text" name="name" class="form-control" required autofocus>
          </div>
          <div class="form-group">
            <label><?php echo e($page('email')); ?></label>
            <input type="text" name="email" class="form-control" required>
          </div>
          <div class="form-group">
            <label><?php echo e($page('password')); ?></label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <div class="form-group">
            <label><?php echo e($page('password_confirmation')); ?></label>
            <input type="password" name="password_confirmation" class="form-control" required>
          </div>
          <div class="form-group d-flex
          ">
            <button type="submit" class="btn btn-primary ml-auto">
              <?php echo e($page('submit')); ?>

            </button>
          </div>
        </form>
        <?php echo $__env->make('auth.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <div class="card-footer d-flex justify-content-around">
        <a href="<?php echo e(route('auth.signin')); ?>"><?php echo e($page('signin')); ?></a>
        <a href="<?php echo e(route('auth.forgotten')); ?>" class="ml-auto">
          <?php echo e($page('forgotten')); ?>

        </a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/auth/signup.blade.php ENDPATH**/ ?>