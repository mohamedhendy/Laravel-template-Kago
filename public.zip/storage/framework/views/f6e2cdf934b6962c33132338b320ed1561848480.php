<?php
$page = page('registration');
$title = $page('title');
?>
<?php $__env->startSection('content'); ?>
<div class="container jobs-applications">
  <h1 class="text-center"><?php echo e($page('title', 'application')); ?></h1>

  <div class="p-5 stipulations border">
    <h3 class="text-center"><?php echo e($page('title','registration')); ?></h3>
    <div class="row">
      <div class="col-md-6">
        <ul class="list-unstyled">
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
        </ul>
      </div>
      <div class="col-md-6">
        <ul class="list-unstyled">
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
          <li><?php echo e($page('excerpt','registration')); ?></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\kag-school\resources\views/front/registration.blade.php ENDPATH**/ ?>