<link rel="stylesheet" href="<?php echo e(asset(mix('/css/base.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('/css/back.css'))); ?>">
<?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/auth/layout/styles.blade.php ENDPATH**/ ?>