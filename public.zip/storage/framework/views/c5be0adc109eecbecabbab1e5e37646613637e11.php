<?php $site = page('auth-layout'); ?>
<!DOCTYPE html>
<html lang="<?php echo e($locale); ?>" dir="<?php echo e($direction); ?>">
<head>
<?php echo $__env->make('auth.layout.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('auth.layout.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('auth.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="<?php echo e($direction); ?>">
  <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/auth/layout.blade.php ENDPATH**/ ?>