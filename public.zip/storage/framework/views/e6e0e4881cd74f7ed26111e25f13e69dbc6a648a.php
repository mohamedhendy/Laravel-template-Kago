<?php $site = page('layout'); ?>
<!DOCTYPE html>
<html lang="<?php echo e($locale); ?>" dir="<?php echo e($direction); ?>">
<head>
<?php echo $__env->make('front.layout.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('front.layout.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('front.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="<?php echo e($direction); ?>">
<div class="root">
  <header>
    <nav class="navbar navbar-expand-lg navbar-light menu py-0">
      <?php echo $__env->make('front.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
  </header>
  <aside class="alerts"><?php echo $__env->make('front.layout.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></aside>
  <main class="content"><?php echo $__env->yieldContent('content'); ?></main>
  <footer>
    <div class="footer">
      <?php echo $__env->make('front.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="footer-bottom">
      <div class="container d-md-flex text-center">
          <div class="social "><?php echo $__env->make('front.layout.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
          <div class="copyright c-right ml-auto text-white">
            <?php echo $site('copyright'); ?>

          </div>
      </div>
    </div>
  </footer>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\kag-school\resources\views/front/layout.blade.php ENDPATH**/ ?>