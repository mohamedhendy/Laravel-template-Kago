<?php
$page = page('gallery');
$title = $page('title');
?>
<?php $__env->startSection('content'); ?>
<h1 class="text-center"><?php echo e($page('title', 'images')); ?></h1>
<div class="container">
  <div class="row gallery">
    <div class="col-12">
      <img class="w-100" src="<?php echo e($page('image','large')); ?>" alt="">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
    <div class="col-md-6">
      <img class="pd-1 w-100" src="<?php echo e($page('image','medium')); ?>" alt="image">
    </div>
    <div class="col-md-6">
      <img class="pd-1 w-100" src="<?php echo e($page('image','medium')); ?>" alt="image">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
    <div class="col-md-3">
      <img class="pd-1 w-100" src="<?php echo e($page('image','small')); ?>" alt="image">
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/front/gallery.blade.php ENDPATH**/ ?>