<script defer src="<?php echo e(asset(mix('/js/manifest.js'))); ?>"></script>
<script defer src="<?php echo e(asset(mix('/js/vendor.js'))); ?>"></script>
<script defer src="<?php echo e(asset(mix('/js/front.js'))); ?>"></script>
<?php /**PATH C:\xampp\htdocs\school\kag-school\resources\views/front/layout/scripts.blade.php ENDPATH**/ ?>