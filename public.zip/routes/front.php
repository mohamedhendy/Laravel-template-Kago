<?php

Route::view('', 'front.home')->name('front.home');
Route::view('about', 'front.about')->name('front.about');
Route::view('contact', 'front.contact')->name('front.contact');
Route::view('gallery', 'front.gallery')->name('front.gallery');
Route::view('home', 'front.home')->name('front.home');
Route::view('jobs-application', 'front.jobs-application')->name('front.jobs-application');
Route::view('jobs', 'front.jobs')->name('front.jobs');
Route::view('news', 'front.news')->name('front.news');
Route::view('polls', 'front.polls')->name('front.polls');
Route::view('registration', 'front.registration')->name('front.registration');
